// src/Components/navbar/Navbar.tsx
import { useEffect, useState } from "react";
import { useChemUIStore } from "../../store/chemUIStore";
import type { WorkspaceTool } from "../../types/chem";
import styles from "./Navbar.module.css";

const WORKSPACE_TOOLS: { id: WorkspaceTool; label: string }[] = [
  { id: "select", label: "Select" },
  { id: "erase", label: "Erase" },
  { id: "lasso", label: "Lasso" },
];

export default function Navbar() {
  const workspaceTool = useChemUIStore((s) => s.workspaceTool);
  const setWorkspaceTool = useChemUIStore((s) => s.setWorkspaceTool);
  const undo = useChemUIStore((s) => s.undo);
  const redo = useChemUIStore((s) => s.redo);
  const canUndo = useChemUIStore((s) => s.undoStack.length > 0);
  const canRedo = useChemUIStore((s) => s.redoStack.length > 0);
  const newMolecule = useChemUIStore((s) => s.newMolecule);
  const atomCount = useChemUIStore((s) => s.atoms.length);
  const theme = useChemUIStore((s) => s.theme);
  const toggleTheme = useChemUIStore((s) => s.toggleTheme);

  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
  }, [theme]);

  function flash(text: string) {
    setMessage(text);
    window.setTimeout(() => setMessage(null), 1800);
  }

  function handleNew() {
    if (atomCount > 0 && !window.confirm("Start a new molecule? Unsaved work will be lost.")) {
      return;
    }
    newMolecule();
    flash("New molecule started");
  }

  return (
    <header className={styles.navbar}>
      <div className={styles.logo}>
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true">
          <circle cx="7" cy="13" r="2.4" fill="var(--ce-active-text)" />
          <circle cx="13" cy="13" r="2.4" fill="var(--ce-el-o)" />
          <circle cx="10" cy="6.5" r="2.4" fill="var(--ce-el-n)" />
          <line x1="7" y1="13" x2="10" y2="6.5" stroke="var(--ce-text-dim)" strokeWidth="1.3" />
          <line x1="13" y1="13" x2="10" y2="6.5" stroke="var(--ce-text-dim)" strokeWidth="1.3" />
        </svg>
        <span>ChemEase</span>
      </div>

      <div className={styles.divider} />

      <div className={styles.btnGroup} role="group" aria-label="Workspace tool">
        {WORKSPACE_TOOLS.map((tool) => (
          <button
            key={tool.id}
            type="button"
            className={workspaceTool === tool.id ? styles.active : undefined}
            onClick={() => setWorkspaceTool(tool.id)}
          >
            {tool.label}
          </button>
        ))}
      </div>

      <div className={styles.divider} />

      <button
        type="button"
        className={styles.iconBtn}
        title="Undo"
        aria-label="Undo"
        disabled={!canUndo}
        onClick={undo}
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M9 14 4 9l5-5" />
          <path d="M4 9h10.5a5.5 5.5 0 0 1 0 11H11" />
        </svg>
      </button>
      <button
        type="button"
        className={styles.iconBtn}
        title="Redo"
        aria-label="Redo"
        disabled={!canRedo}
        onClick={redo}
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="m15 14 5-5-5-5" />
          <path d="M20 9H9.5a5.5 5.5 0 0 0 0 11H13" />
        </svg>
      </button>

      <div className={styles.divider} />

      <div className={styles.fileActions}>
        <button type="button" onClick={handleNew}>New</button>
        <button type="button" onClick={() => flash("Molecule saved")}>Save</button>
        <button type="button" onClick={() => flash("Export coming soon")}>Export</button>
      </div>

      <div className={styles.spacer} />

      {message && <span className={styles.flashMessage}>{message}</span>}

      <button
        type="button"
        className={styles.themeToggle}
        data-on={theme === "dark"}
        title="Toggle theme"
        aria-label="Toggle light and dark theme"
        onClick={toggleTheme}
      />
    </header>
  );
}
