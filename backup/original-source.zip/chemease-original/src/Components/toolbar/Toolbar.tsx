// src/Components/toolbar/Toolbar.tsx
import { useState, type ReactNode } from "react";
import { useChemUIStore } from "../../store/chemUIStore";
import {
  COMMON_ELEMENTS,
  HALOGEN_ELEMENTS,
  EXTENDED_ELEMENTS,
  type BondType,
} from "../../types/chem";
import { CANVAS_CENTER } from "../../utils/canvasConfig";
import styles from "./Toolbar.module.css";

type SectionId = "atoms" | "bonds" | "rings" | "charge" | "special";

const BOND_OPTIONS: { id: BondType; label: string }[] = [
  { id: "single", label: "Single" },
  { id: "double", label: "Double" },
  { id: "triple", label: "Triple" },
  { id: "aromatic", label: "Aromatic" },
];

export default function Toolbar() {
  const [collapsed, setCollapsed] = useState(false);
  const [openSections, setOpenSections] = useState<Record<SectionId, boolean>>({
    atoms: true,
    bonds: false,
    rings: false,
    charge: false,
    special: false,
  });
  const [showPeriodicTable, setShowPeriodicTable] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);

  const activeAtom = useChemUIStore((s) => s.activeAtom);
  const activeBond = useChemUIStore((s) => s.activeBond);
  const bondChosen = useChemUIStore((s) => s.bondChosen);
  const workspaceTool = useChemUIStore((s) => s.workspaceTool);
  const setActiveAtom = useChemUIStore((s) => s.setActiveAtom);
  const setActiveBond = useChemUIStore((s) => s.setActiveBond);
  const addRing = useChemUIStore((s) => s.addRing);

  function toggleSection(id: SectionId) {
    setOpenSections((prev) => ({ ...prev, [id]: !prev[id] }));
  }

  function flash(text: string) {
    setNotice(text);
    window.setTimeout(() => setNotice(null), 1800);
  }

  function handleRing(size: 5 | 6, aromatic: boolean, label: string) {
    addRing(size, aromatic, CANVAS_CENTER.x, CANVAS_CENTER.y);
    flash(`${label} added`);
  }

  const isAtomActive = (el: string) => workspaceTool === "draw" && activeAtom === el;
  const isBondActive = (type: BondType) => workspaceTool === "bond" && bondChosen && activeBond === type;

  return (
    <aside className={`${styles.toolbar} ${collapsed ? styles.collapsed : ""}`}>
      <div className={styles.head}>
        <button
          type="button"
          className={styles.collapseBtn}
          style={{ transform: collapsed ? "rotate(180deg)" : "rotate(0deg)" }}
          onClick={() => setCollapsed((c) => !c)}
          title={collapsed ? "Expand toolbar" : "Collapse toolbar"}
          aria-label="Toggle toolbar width"
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
            <path d="m15 18-6-6 6-6" />
          </svg>
        </button>
      </div>

      <div className={styles.scroll}>
        {/* ATOMS */}
        <Section id="atoms" label="Atoms" open={openSections.atoms} onToggle={toggleSection}>
          <div className={styles.grid}>
            {[...COMMON_ELEMENTS, ...HALOGEN_ELEMENTS].map((el) => (
              <button
                key={el}
                type="button"
                className={`${styles.item} ${isAtomActive(el) ? styles.itemActive : ""}`}
                style={{ color: `var(--ce-el-${el.toLowerCase()}, var(--ce-el-default))` }}
                onClick={() => setActiveAtom(el)}
              >
                {el}
              </button>
            ))}
            <button
              type="button"
              className={`${styles.item} ${styles.itemMore}`}
              onClick={() => setShowPeriodicTable(true)}
            >
              + More
            </button>
          </div>
        </Section>

        {/* BONDS */}
        <Section id="bonds" label="Bonds" open={openSections.bonds} onToggle={toggleSection}>
          <div className={styles.grid}>
            {BOND_OPTIONS.map((bond) => (
              <button
                key={bond.id}
                type="button"
                title={bond.label}
                className={`${styles.item} ${isBondActive(bond.id) ? styles.itemActive : ""}`}
                onClick={() => setActiveBond(bond.id)}
              >
                <BondIcon type={bond.id} />
              </button>
            ))}
          </div>
        </Section>

        {/* RINGS */}
        <Section id="rings" label="Rings" open={openSections.rings} onToggle={toggleSection}>
          <div className={styles.grid}>
            <button type="button" className={styles.item} title="5-membered ring" onClick={() => handleRing(5, false, "5-membered ring")}>
              <RingIcon sides={5} />
            </button>
            <button type="button" className={styles.item} title="6-membered ring / cyclohexane" onClick={() => handleRing(6, false, "Cyclohexane ring")}>
              <RingIcon sides={6} />
            </button>
            <button type="button" className={styles.item} title="Benzene" onClick={() => handleRing(6, true, "Benzene ring")}>
              <RingIcon sides={6} aromatic />
            </button>
          </div>
        </Section>

        {/* CHARGE */}
        <Section id="charge" label="Charge" open={openSections.charge} onToggle={toggleSection}>
          <div className={styles.grid}>
            <button type="button" className={styles.item} onClick={() => flash("Select an atom, then apply +1 (coming soon)")}>+1</button>
            <button type="button" className={styles.item} onClick={() => flash("Select an atom, then apply −1 (coming soon)")}>−1</button>
          </div>
        </Section>

        {/* SPECIAL */}
        <Section id="special" label="Special" open={openSections.special} onToggle={toggleSection}>
          <div className={styles.grid}>
            <button type="button" className={`${styles.item} ${styles.itemMore}`} onClick={() => flash("R group — coming in a future version")}>R group</button>
            <button type="button" className={`${styles.item} ${styles.itemMore}`} onClick={() => flash("Lone pair — coming in a future version")}>Lone pair</button>
            <button type="button" className={`${styles.item} ${styles.itemMore}`} onClick={() => flash("Reaction arrow — coming in a future version")}>Rxn arrow</button>
            <button type="button" className={`${styles.item} ${styles.itemMore}`} onClick={() => flash("Electron pushing — coming in a future version")}>Electron push</button>
          </div>
        </Section>
      </div>

      {notice && <div className={styles.toast}>{notice}</div>}

      {showPeriodicTable && (
        <div className={styles.modalOverlay} onClick={(e) => { if (e.target === e.currentTarget) setShowPeriodicTable(false); }}>
          <div className={styles.modal}>
            <div className={styles.modalHead}>
              <h3>More elements</h3>
              <button type="button" onClick={() => setShowPeriodicTable(false)} aria-label="Close">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round">
                  <path d="M18 6 6 18M6 6l12 12" />
                </svg>
              </button>
            </div>
            <div className={styles.modalGrid}>
              {EXTENDED_ELEMENTS.map((el) => (
                <button
                  key={el}
                  type="button"
                  onClick={() => {
                    setActiveAtom(el);
                    setShowPeriodicTable(false);
                    flash(`${el} set as active atom`);
                  }}
                >
                  {el}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </aside>
  );
}

function Section({
  id,
  label,
  open,
  onToggle,
  children,
}: {
  id: SectionId;
  label: string;
  open: boolean;
  onToggle: (id: SectionId) => void;
  children: ReactNode;
}) {
  return (
    <div className={`${styles.section} ${open ? styles.sectionOpen : ""}`}>
      <button type="button" className={styles.sectionHead} onClick={() => onToggle(id)}>
        <svg className={styles.chev} width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
          <path d="m9 18 6-6-6-6" />
        </svg>
        <span className={styles.sectionLabel}>{label}</span>
      </button>
      <div className={styles.sectionBody}>{children}</div>
    </div>
  );
}

function BondIcon({ type }: { type: BondType }) {
  if (type === "single") {
    return (
      <svg width="26" height="14" viewBox="0 0 26 14">
        <line x1="2" y1="7" x2="24" y2="7" stroke="currentColor" strokeWidth="2" />
      </svg>
    );
  }
  if (type === "double") {
    return (
      <svg width="26" height="14" viewBox="0 0 26 14">
        <line x1="2" y1="5" x2="24" y2="5" stroke="currentColor" strokeWidth="2" />
        <line x1="2" y1="9" x2="24" y2="9" stroke="currentColor" strokeWidth="2" />
      </svg>
    );
  }
  if (type === "triple") {
    return (
      <svg width="26" height="14" viewBox="0 0 26 14">
        <line x1="2" y1="3" x2="24" y2="3" stroke="currentColor" strokeWidth="1.8" />
        <line x1="2" y1="7" x2="24" y2="7" stroke="currentColor" strokeWidth="1.8" />
        <line x1="2" y1="11" x2="24" y2="11" stroke="currentColor" strokeWidth="1.8" />
      </svg>
    );
  }
  return (
    <svg width="26" height="14" viewBox="0 0 26 14">
      <line x1="2" y1="7" x2="24" y2="7" stroke="currentColor" strokeWidth="2" />
      <line x1="2" y1="3" x2="24" y2="3" stroke="currentColor" strokeWidth="1.4" strokeDasharray="3 2" />
    </svg>
  );
}

function RingIcon({ sides, aromatic }: { sides: 5 | 6; aromatic?: boolean }) {
  const points =
    sides === 5
      ? "10,2 18,8 15,17 5,17 2,8"
      : "10,2 17,6 17,14 10,18 3,14 3,6";
  return (
    <svg width="20" height="20" viewBox="0 0 20 20">
      <polygon points={points} fill="none" stroke="currentColor" strokeWidth="1.6" />
      {aromatic && <circle cx="10" cy="10" r="4.2" fill="none" stroke="currentColor" strokeWidth="1.2" />}
    </svg>
  );
}
