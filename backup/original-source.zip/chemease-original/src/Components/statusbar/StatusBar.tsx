// src/Components/statusbar/StatusBar.tsx
import { useChemUIStore } from "../../store/chemUIStore";
import styles from "./StatusBar.module.css";

const TOOL_LABELS: Record<string, string> = {
  select: "Select",
  erase: "Erase",
  lasso: "Lasso",
  draw: "Draw",
  bond: "Bond",
};

export default function StatusBar() {
  const workspaceTool = useChemUIStore((s) => s.workspaceTool);
  const cursor = useChemUIStore((s) => s.cursor);
  const atomCount = useChemUIStore((s) => s.atoms.length);
  const bondCount = useChemUIStore((s) => s.bonds.length);
  const zoom = useChemUIStore((s) => s.zoom);
  const setZoom = useChemUIStore((s) => s.setZoom);
  const resetView = useChemUIStore((s) => s.resetView);

  return (
    <footer className={styles.bar}>
      <div className={styles.left}>
        <span>Tool: <b>{TOOL_LABELS[workspaceTool] ?? workspaceTool}</b></span>
        <span>X: <b>{cursor.x ?? "—"}</b></span>
        <span>Y: <b>{cursor.y ?? "—"}</b></span>
        <span>Atoms: <b>{atomCount}</b></span>
        <span>Bonds: <b>{bondCount}</b></span>
      </div>
      <div className={styles.right}>
        <div className={styles.zoomGroup}>
          <button type="button" onClick={() => setZoom(zoom - 15)} aria-label="Zoom out">−</button>
          <span className={styles.zoomValue}>{Math.round(zoom)}%</span>
          <button type="button" onClick={() => setZoom(zoom + 15)} aria-label="Zoom in">+</button>
        </div>
        <button type="button" className={styles.fitBtn} onClick={resetView}>Fit</button>
      </div>
    </footer>
  );
}
