// src/Components/canvas/Canvas.tsx
//
// Placeholder interactive canvas: click-to-place atoms, click-two-atoms to
// bond, drag to reposition, erase tool to delete. This is intentionally a
// simple mock so the surrounding UI (info panel, status bar) has real state
// to react to — it is NOT the chemistry-aware drawing engine. Swap the
// atom/bond rendering and interaction logic here once that engine exists;
// the rest of the app only depends on `useChemUIStore`, so this file is the
// single place that needs to change.

import { useRef, type MouseEvent as ReactMouseEvent } from "react";
import { useChemUIStore } from "../../store/chemUIStore";
import type { Atom, Bond } from "../../types/chem";
import { elementColorVar } from "../../utils/elementColor";
import { CANVAS_WIDTH, CANVAS_HEIGHT } from "../../utils/canvasConfig";
import styles from "./Canvas.module.css";

export default function Canvas() {
  const svgRef = useRef<SVGSVGElement>(null);

  const atoms = useChemUIStore((s) => s.atoms);
  const bonds = useChemUIStore((s) => s.bonds);
  const workspaceTool = useChemUIStore((s) => s.workspaceTool);
  const activeAtom = useChemUIStore((s) => s.activeAtom);
  const selectedAtomId = useChemUIStore((s) => s.selectedAtomId);
  const pendingBondAtomId = useChemUIStore((s) => s.pendingBondAtomId);
  const zoom = useChemUIStore((s) => s.zoom);

  const addAtom = useChemUIStore((s) => s.addAtom);
  const moveAtom = useChemUIStore((s) => s.moveAtom);
  const removeAtom = useChemUIStore((s) => s.removeAtom);
  const removeBond = useChemUIStore((s) => s.removeBond);
  const selectAtom = useChemUIStore((s) => s.selectAtom);
  const startOrCompleteBond = useChemUIStore((s) => s.startOrCompleteBond);
  const setCursor = useChemUIStore((s) => s.setCursor);
  const setZoom = useChemUIStore((s) => s.setZoom);

  const viewBox = getViewBox(zoom);

  function toSvgPoint(clientX: number, clientY: number) {
    const svg = svgRef.current;
    if (!svg) return { x: 0, y: 0 };
    const pt = svg.createSVGPoint();
    pt.x = clientX;
    pt.y = clientY;
    const ctm = svg.getScreenCTM();
    if (!ctm) return { x: 0, y: 0 };
    const p = pt.matrixTransform(ctm.inverse());
    return { x: p.x, y: p.y };
  }

  function handleCanvasClick(e: ReactMouseEvent<SVGSVGElement>) {
    if (workspaceTool !== "draw" || !activeAtom) return;
    const p = toSvgPoint(e.clientX, e.clientY);
    addAtom(activeAtom, p.x, p.y);
  }

  function handleCanvasMouseMove(e: ReactMouseEvent<SVGSVGElement>) {
    const p = toSvgPoint(e.clientX, e.clientY);
    setCursor(Math.round(p.x), Math.round(p.y));
  }

  function handleCanvasMouseLeave() {
    setCursor(null, null);
  }

  function handleAtomMouseDown(e: ReactMouseEvent, atom: Atom) {
    e.stopPropagation();

    if (workspaceTool === "erase") {
      removeAtom(atom.id);
      return;
    }

    if (workspaceTool === "bond") {
      startOrCompleteBond(atom.id);
      return;
    }

    // default: select + drag
    selectAtom(atom.id);
    let moved = false;

    function onMove(ev: MouseEvent) {
      const p = toSvgPoint(ev.clientX, ev.clientY);
      moved = true;
      moveAtom(atom.id, p.x, p.y);
    }
    function onUp() {
      document.removeEventListener("mousemove", onMove);
      document.removeEventListener("mouseup", onUp);
      if (!moved) selectAtom(atom.id);
    }
    document.addEventListener("mousemove", onMove);
    document.addEventListener("mouseup", onUp);
  }

  function handleBondMouseDown(e: ReactMouseEvent, bond: Bond) {
    e.stopPropagation();
    if (workspaceTool === "erase") {
      removeBond(bond.id);
    }
  }

  function handleWheel(e: React.WheelEvent<SVGSVGElement>) {
    e.preventDefault();
    setZoom(zoom + (e.deltaY < 0 ? 10 : -10));
  }

  return (
    <div className={styles.wrap}>
      {atoms.length === 0 && (
        <div className={styles.emptyMessage}>
          <div className={styles.emptyTitle}>Start drawing</div>
          <div className={styles.emptySubtitle}>
            Select an element from the toolbar
            <br />
            and click on the canvas
          </div>
        </div>
      )}

      <svg
        ref={svgRef}
        className={styles.canvas}
        viewBox={`${viewBox.x} ${viewBox.y} ${viewBox.w} ${viewBox.h}`}
        preserveAspectRatio="xMidYMid meet"
        onClick={handleCanvasClick}
        onMouseMove={handleCanvasMouseMove}
        onMouseLeave={handleCanvasMouseLeave}
        onWheel={handleWheel}
        role="img"
        aria-label="Chemical structure drawing canvas"
      >
        {bonds.map((bond) => {
          const a1 = atoms.find((a) => a.id === bond.atomA);
          const a2 = atoms.find((a) => a.id === bond.atomB);
          if (!a1 || !a2) return null;
          return (
            <BondShape
              key={bond.id}
              bond={bond}
              a1={a1}
              a2={a2}
              onMouseDown={(e) => handleBondMouseDown(e, bond)}
              erasing={workspaceTool === "erase"}
            />
          );
        })}

        {atoms.map((atom) => (
          <AtomShape
            key={atom.id}
            atom={atom}
            selected={atom.id === selectedAtomId || atom.id === pendingBondAtomId}
            erasing={workspaceTool === "erase"}
            onMouseDown={(e) => handleAtomMouseDown(e, atom)}
          />
        ))}
      </svg>
    </div>
  );
}

function getViewBox(zoomPercent: number) {
  const factor = 100 / zoomPercent;
  const w = CANVAS_WIDTH * factor;
  const h = CANVAS_HEIGHT * factor;
  const cx = CANVAS_WIDTH / 2;
  const cy = CANVAS_HEIGHT / 2;
  return { x: cx - w / 2, y: cy - h / 2, w, h };
}

function AtomShape({
  atom,
  selected,
  erasing,
  onMouseDown,
}: {
  atom: Atom;
  selected: boolean;
  erasing: boolean;
  onMouseDown: (e: ReactMouseEvent) => void;
}) {
  return (
    <g style={{ cursor: erasing ? "not-allowed" : "pointer" }} onMouseDown={onMouseDown}>
      {selected && (
        <circle cx={atom.x} cy={atom.y} r={17} className={styles.selectionRing} />
      )}
      <circle cx={atom.x} cy={atom.y} r={13} fill="var(--ce-bg-canvas)" />
      <text
        x={atom.x}
        y={atom.y + 0.5}
        className={styles.atomLabel}
        fill={elementColorVar(atom.element)}
      >
        {atom.element}
      </text>
      <circle cx={atom.x} cy={atom.y} r={16} className={styles.atomHit} />
    </g>
  );
}

function BondShape({
  bond,
  a1,
  a2,
  onMouseDown,
  erasing,
}: {
  bond: Bond;
  a1: Atom;
  a2: Atom;
  onMouseDown: (e: ReactMouseEvent) => void;
  erasing: boolean;
}) {
  const dx = a2.x - a1.x;
  const dy = a2.y - a1.y;
  const len = Math.sqrt(dx * dx + dy * dy) || 1;
  const nx = -dy / len;
  const ny = dx / len;
  const ux = dx / len;
  const uy = dy / len;

  const lines: { x1: number; y1: number; x2: number; y2: number; dashed?: boolean }[] = [];

  if (bond.type === "single") {
    lines.push({ x1: a1.x, y1: a1.y, x2: a2.x, y2: a2.y });
  } else if (bond.type === "double") {
    const off = 3.2;
    lines.push({ x1: a1.x + nx * off, y1: a1.y + ny * off, x2: a2.x + nx * off, y2: a2.y + ny * off });
    lines.push({ x1: a1.x - nx * off, y1: a1.y - ny * off, x2: a2.x - nx * off, y2: a2.y - ny * off });
  } else if (bond.type === "triple") {
    const off = 4.5;
    lines.push({ x1: a1.x, y1: a1.y, x2: a2.x, y2: a2.y });
    lines.push({ x1: a1.x + nx * off, y1: a1.y + ny * off, x2: a2.x + nx * off, y2: a2.y + ny * off });
    lines.push({ x1: a1.x - nx * off, y1: a1.y - ny * off, x2: a2.x - nx * off, y2: a2.y - ny * off });
  } else {
    const off = 3.5;
    const inset = 6;
    lines.push({ x1: a1.x, y1: a1.y, x2: a2.x, y2: a2.y });
    lines.push({
      x1: a1.x + nx * off + ux * inset,
      y1: a1.y + ny * off + uy * inset,
      x2: a2.x + nx * off - ux * inset,
      y2: a2.y + ny * off - uy * inset,
      dashed: true,
    });
  }

  return (
    <g>
      {lines.map((l, i) => (
        <line
          key={i}
          x1={l.x1}
          y1={l.y1}
          x2={l.x2}
          y2={l.y2}
          className={styles.bondLine}
          strokeDasharray={l.dashed ? "4 3" : undefined}
        />
      ))}
      <line
        x1={a1.x}
        y1={a1.y}
        x2={a2.x}
        y2={a2.y}
        className={styles.bondHit}
        style={{ cursor: erasing ? "not-allowed" : "default" }}
        onMouseDown={onMouseDown}
      />
    </g>
  );
}
