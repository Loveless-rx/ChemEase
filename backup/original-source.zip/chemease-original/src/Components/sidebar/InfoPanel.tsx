// src/Components/sidebar/InfoPanel.tsx
//
// Formula / molecular weight / SMILES are intentionally NOT calculated here
// — per scope, no chemistry logic lives in the frontend yet. They render as
// placeholders that make it obvious more is coming, so it's easy to swap in
// real values once the chemistry engine exists (search for "PENDING_LABEL").

import { useState } from "react";
import { useChemUIStore } from "../../store/chemUIStore";
import {
  calculateFormula,
  calculateMolecularWeight,
} from "../../engine/chemistry";
import styles from "./InfoPanel.module.css";

const TOOL_LABELS: Record<string, string> = {
  select: "Select",
  erase: "Erase",
  lasso: "Lasso",
  draw: "Draw",
  bond: "Bond",
};

const BOND_LABELS: Record<string, string> = {
  single: "Single",
  double: "Double",
  triple: "Triple",
  aromatic: "Aromatic",
};

export default function InfoPanel() {
  const workspaceTool = useChemUIStore((s) => s.workspaceTool);
  const activeAtom = useChemUIStore((s) => s.activeAtom);
  const activeBond = useChemUIStore((s) => s.activeBond);
  const bondChosen = useChemUIStore((s) => s.bondChosen);

  const atoms = useChemUIStore((s) => s.atoms);
  const bondCount = useChemUIStore((s) => s.bonds.length);

  const [notice, setNotice] = useState<string | null>(null);

  function flash(text: string) {
    setNotice(text);
    window.setTimeout(() => setNotice(null), 1800);
  }

  const atomCount = atoms.length;
  const hasMolecule = atomCount > 0;

  const formula = calculateFormula(atoms);
  const molecularWeight = calculateMolecularWeight(atoms);

  return (
    <aside className={styles.panel}>
      <div className={styles.scroll}>
        <p className={styles.title}>Information</p>

        <div className={styles.block}>
          <div className={styles.label}>Tool</div>
          <div className={styles.value}>
            {TOOL_LABELS[workspaceTool] ?? workspaceTool}
          </div>
        </div>

        <div className={styles.block}>
          <div className={styles.label}>Atom</div>
          <div className={activeAtom ? styles.value : styles.valueMuted}>
            {activeAtom ?? "—"}
          </div>
        </div>

        <div className={styles.block}>
          <div className={styles.label}>Bond</div>
          <div className={bondChosen ? styles.value : styles.valueMuted}>
            {bondChosen ? BOND_LABELS[activeBond] : "—"}
          </div>
        </div>

        <div className={styles.divider} />

        <div className={styles.label} style={{ marginBottom: 8 }}>
          Molecule
        </div>

        <Row k="Atoms" v={String(atomCount)} />
        <Row k="Bonds" v={String(bondCount)} />
        <Row k="Formula" v={formula} />

        <Row
          k="MW"
          v={
            molecularWeight === null
              ? "—"
              : `${molecularWeight.toFixed(2)} g/mol`
          }
        />
      </div>

      {notice && <div className={styles.toast}>{notice}</div>}

      <div className={styles.actions}>
        <button
          type="button"
          className={styles.primary}
          onClick={() =>
            flash(
              hasMolecule
                ? "Structure analysis coming soon"
                : "Draw a structure first"
            )
          }
        >
          Analyze Structure
        </button>

        <button
          type="button"
          onClick={() =>
            flash(
              hasMolecule
                ? "SMILES generation coming soon"
                : "Draw a structure first"
            )
          }
        >
          Copy SMILES
        </button>

        <button
          type="button"
          onClick={() =>
            flash(
              hasMolecule
                ? "Export coming soon"
                : "Draw a structure first"
            )
          }
        >
          Download PNG
        </button>
      </div>
    </aside>
  );
}

function Row({
  k,
  v,
}: {
  k: string;
  v: string;
}) {
  return (
    <div className={styles.row}>
      <span className={styles.rowKey}>{k}</span>
      <span className={styles.rowValue}>{v}</span>
    </div>
  );
}