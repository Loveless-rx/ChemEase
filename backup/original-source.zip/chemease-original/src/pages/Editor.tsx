import Navbar from "../Components/navbar/Navbar";
import Toolbar from "../Components/toolbar/Toolbar";
import Canvas from "../Components/canvas/Canvas";
import InfoPanel from "../Components/sidebar/InfoPanel";
import StatusBar from "../Components/statusbar/StatusBar";

export default function Editor() {
  return (
    <div
      className="
      w-screen
      h-screen
      flex
      flex-col
      overflow-hidden
      "
    >
      <Navbar />

      <div className="flex flex-1 overflow-hidden">

        <Toolbar />

        <Canvas />

        <InfoPanel />

      </div>

      <StatusBar />
    </div>
  );
}

