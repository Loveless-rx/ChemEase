// src/utils/canvasConfig.ts
export const CANVAS_WIDTH = 1000;
export const CANVAS_HEIGHT = 700;
export const CANVAS_CENTER = { x: CANVAS_WIDTH / 2, y: CANVAS_HEIGHT / 2 };
