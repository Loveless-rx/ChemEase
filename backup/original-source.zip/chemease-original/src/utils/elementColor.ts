// src/utils/elementColor.ts
const ELEMENT_COLOR_VARS: Record<string, string> = {
  C: "--ce-el-c",
  H: "--ce-el-h",
  N: "--ce-el-n",
  O: "--ce-el-o",
  P: "--ce-el-p",
  S: "--ce-el-s",
  F: "--ce-el-f",
  Cl: "--ce-el-cl",
  Br: "--ce-el-br",
  I: "--ce-el-i",
};

export function elementColorVar(element: string): string {
  return `var(${ELEMENT_COLOR_VARS[element] ?? "--ce-el-default"})`;
}
