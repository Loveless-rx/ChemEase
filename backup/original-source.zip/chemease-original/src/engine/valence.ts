import type { Atom, Bond, BondType } from "../types/chem";

/**
 * Bond-order interpretation used by the chemistry engine.
 *
 * The UI still stores bonds as "single", "double", etc.
 * This converts them into numerical orders for valence calculations.
 */
export function getBondOrder(type: BondType): number {
  switch (type) {
    case "single":
      return 1;

    case "double":
      return 2;

    case "triple":
      return 3;

    case "aromatic":
      return 1.5;

    default:
      return 1;
  }
}

/**
 * Basic default valence values for the elements currently supported
 * by ChemEase.
 *
 * This is intentionally a first-stage engine. More advanced chemistry
 * such as radicals, hypervalent atoms, resonance and special oxidation
 * states can be added later.
 */
const DEFAULT_VALENCE: Record<string, number> = {
  H: 1,
  C: 4,
  N: 3,
  O: 2,
  F: 1,
  P: 3,
  S: 2,

  Cl: 1,
  Br: 1,
  I: 1,

  B: 3,
  Si: 4,

  Li: 1,
  Na: 1,
  K: 1,

  Mg: 2,
  Ca: 2,

  Al: 3,

  Zn: 2,
  Fe: 3,
  Cu: 2,
  Ag: 1,
};

/**
 * Returns the total bond order connected to an atom.
 */
export function getBondOrderSum(
  atomId: number,
  bonds: Bond[]
): number {
  return bonds.reduce((sum, bond) => {
    if (bond.atomA !== atomId && bond.atomB !== atomId) {
      return sum;
    }

    return sum + getBondOrder(bond.type);
  }, 0);
}

/**
 * Returns the number of implicit hydrogens expected for an atom.
 *
 * Example:
 *
 * C with one single bond
 * → bond order = 1
 * → implicit H = 3
 *
 * C with two single bonds
 * → bond order = 2
 * → implicit H = 2
 *
 * C with one double bond
 * → bond order = 2
 * → implicit H = 2
 */
export function getImplicitHydrogens(
  atom: Atom,
  bonds: Bond[]
): number {
  const defaultValence = DEFAULT_VALENCE[atom.element];

  if (defaultValence === undefined) {
    return 0;
  }

  const usedValence = getBondOrderSum(atom.id, bonds);

  const remaining = defaultValence - usedValence;

  return Math.max(0, Math.floor(remaining));
}

/**
 * Calculates implicit hydrogen count for the entire molecule.
 */
export function calculateImplicitHydrogens(
  atoms: Atom[],
  bonds: Bond[]
): number {
  return atoms.reduce(
    (total, atom) => total + getImplicitHydrogens(atom, bonds),
    0
  );
}

/**
 * Returns the total valence currently used by an atom.
 */
export function getUsedValence(
  atomId: number,
  bonds: Bond[]
): number {
  return getBondOrderSum(atomId, bonds);
}

/**
 * Checks whether an atom is exceeding its default valence.
 *
 * This is soft validation:
 * the atom is NOT prevented from being drawn.
 */
export function isAtomOverValent(
  atom: Atom,
  bonds: Bond[]
): boolean {
  const defaultValence = DEFAULT_VALENCE[atom.element];

  if (defaultValence === undefined) {
    return false;
  }

  return getUsedValence(atom.id, bonds) > defaultValence;
}

/**
 * Returns all atoms that currently exceed their basic valence.
 */
export function getOverValentAtoms(
  atoms: Atom[],
  bonds: Bond[]
): Atom[] {
  return atoms.filter((atom) =>
    isAtomOverValent(atom, bonds)
  );
}

/**
 * Returns true when the molecule contains at least one atom
 * that exceeds its basic supported valence.
 */
export function hasValenceErrors(
  atoms: Atom[],
  bonds: Bond[]
): boolean {
  return getOverValentAtoms(atoms, bonds).length > 0;
}