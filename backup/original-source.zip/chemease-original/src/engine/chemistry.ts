import type { Atom, Bond } from "../types/chem";
import { calculateImplicitHydrogens } from "./valence";

const ATOMIC_WEIGHTS: Record<string, number> = {
  H: 1.008,
  C: 12.011,
  N: 14.007,
  O: 15.999,
  F: 18.998,
  P: 30.974,
  S: 32.06,
  Cl: 35.45,
  Br: 79.904,
  I: 126.904,
  B: 10.81,
  Si: 28.085,
  Li: 6.94,
  Na: 22.99,
  K: 39.098,
  Mg: 24.305,
  Ca: 40.078,
  Al: 26.982,
  Zn: 65.38,
  Fe: 55.845,
  Cu: 63.546,
  Ag: 107.868,
};

function countExplicitElements(atoms: Atom[]): Record<string, number> {
  const counts: Record<string, number> = {};

  for (const atom of atoms) {
    counts[atom.element] = (counts[atom.element] ?? 0) + 1;
  }

  return counts;
}

export function calculateFormula(
  atoms: Atom[],
  bonds: Bond[] = []
): string {
  if (atoms.length === 0) {
    return "—";
  }

  const counts = countExplicitElements(atoms);

  // Add implicit hydrogens inferred from valence.
  const implicitHydrogens = calculateImplicitHydrogens(atoms, bonds);

  if (implicitHydrogens > 0) {
    counts.H = (counts.H ?? 0) + implicitHydrogens;
  }

  const elements = Object.keys(counts);

  // Hill-system ordering:
  // C first, H second, everything else alphabetically.
  elements.sort((a, b) => {
    if (a === "C") return -1;
    if (b === "C") return 1;

    if (a === "H") return -1;
    if (b === "H") return 1;

    return a.localeCompare(b);
  });

  return elements
    .map((element) => {
      const count = counts[element];

      return count === 1
        ? element
        : `${element}${count}`;
    })
    .join("");
}

export function calculateMolecularWeight(
  atoms: Atom[],
  bonds: Bond[] = []
): number | null {
  if (atoms.length === 0) {
    return null;
  }

  let weight = 0;

  // Explicit atoms.
  for (const atom of atoms) {
    const atomicWeight = ATOMIC_WEIGHTS[atom.element];

    if (atomicWeight === undefined) {
      return null;
    }

    weight += atomicWeight;
  }

  // Implicit hydrogens.
  const implicitHydrogens = calculateImplicitHydrogens(
    atoms,
    bonds
  );

  weight += implicitHydrogens * ATOMIC_WEIGHTS.H;

  return weight;
}