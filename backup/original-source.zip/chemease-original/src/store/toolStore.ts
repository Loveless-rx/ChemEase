import { create } from "zustand";

interface ToolStore {
  selectedTool: string;
  selectedAtom: string | null;
  selectedBond: string | null;
  setSelectedTool: (tool: string) => void;
  setSelectedAtom: (atom: string) => void;
  setSelectedBond: (bond: string) => void;
}

export const useToolStore = create<ToolStore>((set) => ({
  selectedTool: "select",
  selectedAtom: null,
  selectedBond: null,

  setSelectedTool: (tool) =>
    set({
      selectedTool: tool,
    }),
  setSelectedAtom: (atom) =>
    set({ selectedAtom: atom }),

  setSelectedBond: (bond) =>
    set({ selectedBond: bond }),
}));