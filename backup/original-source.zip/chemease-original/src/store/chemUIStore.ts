// src/store/chemUIStore.ts
//
// NOTE FOR INTEGRATION:
// I don't have visibility into your existing `toolStore.ts`, so this is a
// new, self-contained Zustand store that the five UI components below read
// and write to. It only tracks UI-level state (active tool, mock atoms/
// bonds for layout purposes, zoom, theme) — no chemistry logic lives here,
// per your scope.
//
// If `toolStore.ts` already owns some of this state (e.g. workspaceTool),
// the cleanest path is to either:
//   1) merge the fields below into `toolStore.ts` and re-point these
//      components at `useToolStore`, or
//   2) keep this store for editor-local UI state and have `toolStore.ts`
//      own the real molecule model once the drawing engine lands.
// The components only ever call the hook below (`useChemUIStore`) and never
// reach into global state directly, so repointing them later is a
// find-and-replace of the import.

import { create } from "zustand";
import type { Atom, Bond, BondType, WorkspaceTool } from "../types/chem";

interface HistorySnapshot {
  atoms: Atom[];
  bonds: Bond[];
}

interface ChemUIState {
  // Tool selection
  workspaceTool: WorkspaceTool;
  activeAtom: ElementOrNull;
  activeBond: BondType;
  bondChosen: boolean;
  pendingBondAtomId: number | null;

  // Mock molecule data (placeholder until the real drawing engine lands)
  atoms: Atom[];
  bonds: Bond[];
  selectedAtomId: number | null;
  nextAtomId: number;
  nextBondId: number;

  // Viewport
  zoom: number; // percentage, 25–300
  cursor: { x: number | null; y: number | null };

  // Theme
  theme: "light" | "dark";

  // History
  undoStack: HistorySnapshot[];
  redoStack: HistorySnapshot[];

  // Actions
  setWorkspaceTool: (tool: WorkspaceTool) => void;
  setActiveAtom: (element: string) => void;
  setActiveBond: (type: BondType) => void;
  addAtom: (element: string, x: number, y: number) => void;
  moveAtom: (id: number, x: number, y: number) => void;
  removeAtom: (id: number) => void;
  selectAtom: (id: number | null) => void;
  startOrCompleteBond: (atomId: number) => void;
  removeBond: (id: number) => void;
  addRing: (size: 5 | 6, aromatic: boolean, centerX: number, centerY: number) => void;
  setZoom: (zoom: number) => void;
  resetView: () => void;
  setCursor: (x: number | null, y: number | null) => void;
  toggleTheme: () => void;
  newMolecule: () => void;
  undo: () => void;
  redo: () => void;
}

type ElementOrNull = string | null;

function snapshot(state: ChemUIState): HistorySnapshot {
  return { atoms: state.atoms.map((a) => ({ ...a })), bonds: state.bonds.map((b) => ({ ...b })) };
}

export const useChemUIStore = create<ChemUIState>((set, get) => ({
  workspaceTool: "select",
  activeAtom: null,
  activeBond: "single",
  bondChosen: false,
  pendingBondAtomId: null,

  atoms: [],
  bonds: [],
  selectedAtomId: null,
  nextAtomId: 1,
  nextBondId: 1,

  zoom: 100,
  cursor: { x: null, y: null },

  theme: "light",

  undoStack: [],
  redoStack: [],

  setWorkspaceTool: (tool) =>
    set({ workspaceTool: tool, pendingBondAtomId: null, selectedAtomId: null }),

  setActiveAtom: (element) =>
    set({
      activeAtom: element,
      workspaceTool: "draw",
      pendingBondAtomId: null,
      selectedAtomId: null,
    }),

  setActiveBond: (type) =>
    set({
      activeBond: type,
      bondChosen: true,
      workspaceTool: "bond",
      pendingBondAtomId: null,
      selectedAtomId: null,
    }),

  addAtom: (element, x, y) => {
    const state = get();
    const atom: Atom = { id: state.nextAtomId, element, x, y };
    set({
      atoms: [...state.atoms, atom],
      nextAtomId: state.nextAtomId + 1,
      undoStack: [...state.undoStack, snapshot(state)],
      redoStack: [],
    });
  },

  moveAtom: (id, x, y) =>
    set((state) => ({
      atoms: state.atoms.map((a) => (a.id === id ? { ...a, x, y } : a)),
    })),

  removeAtom: (id) => {
    const state = get();
    set({
      atoms: state.atoms.filter((a) => a.id !== id),
      bonds: state.bonds.filter((b) => b.atomA !== id && b.atomB !== id),
      selectedAtomId: null,
      undoStack: [...state.undoStack, snapshot(state)],
      redoStack: [],
    });
  },

  selectAtom: (id) => set({ selectedAtomId: id }),

  startOrCompleteBond: (atomId) => {
    const state = get();
    if (state.pendingBondAtomId === null) {
      set({ pendingBondAtomId: atomId, selectedAtomId: atomId });
      return;
    }
    if (state.pendingBondAtomId === atomId) {
      set({ pendingBondAtomId: null, selectedAtomId: null });
      return;
    }
    const exists = state.bonds.some(
      (b) =>
        (b.atomA === state.pendingBondAtomId && b.atomB === atomId) ||
        (b.atomB === state.pendingBondAtomId && b.atomA === atomId)
    );
    if (exists) {
      set({ pendingBondAtomId: null, selectedAtomId: null });
      return;
    }
    const bond: Bond = {
      id: state.nextBondId,
      atomA: state.pendingBondAtomId,
      atomB: atomId,
      type: state.activeBond,
    };
    set({
      bonds: [...state.bonds, bond],
      nextBondId: state.nextBondId + 1,
      pendingBondAtomId: null,
      selectedAtomId: null,
      undoStack: [...state.undoStack, snapshot(state)],
      redoStack: [],
    });
  },

  removeBond: (id) => {
    const state = get();
    set({
      bonds: state.bonds.filter((b) => b.id !== id),
      undoStack: [...state.undoStack, snapshot(state)],
      redoStack: [],
    });
  },

  addRing: (size, aromatic, centerX, centerY) => {
    const state = get();
    const radius = 42;
    const ids: number[] = [];
    let atomId = state.nextAtomId;
    const newAtoms: Atom[] = [];
    for (let i = 0; i < size; i++) {
      const angle = -Math.PI / 2 + i * ((2 * Math.PI) / size);
      newAtoms.push({
        id: atomId,
        element: "C",
        x: centerX + radius * Math.cos(angle),
        y: centerY + radius * Math.sin(angle),
      });
      ids.push(atomId);
      atomId++;
    }
    let bondId = state.nextBondId;
    const newBonds: Bond[] = [];
    for (let i = 0; i < size; i++) {
      newBonds.push({
        id: bondId,
        atomA: ids[i],
        atomB: ids[(i + 1) % size],
        type: aromatic && i % 2 === 0 ? "double" : "single",
      });
      bondId++;
    }
    set({
      atoms: [...state.atoms, ...newAtoms],
      bonds: [...state.bonds, ...newBonds],
      nextAtomId: atomId,
      nextBondId: bondId,
      undoStack: [...state.undoStack, snapshot(state)],
      redoStack: [],
    });
  },

  setZoom: (zoom) => set({ zoom: Math.max(25, Math.min(300, zoom)) }),

  resetView: () => set({ zoom: 100 }),

  setCursor: (x, y) => set({ cursor: { x, y } }),

  toggleTheme: () => set((state) => ({ theme: state.theme === "light" ? "dark" : "light" })),

  newMolecule: () => {
    const state = get();
    set({
      atoms: [],
      bonds: [],
      nextAtomId: 1,
      nextBondId: 1,
      selectedAtomId: null,
      pendingBondAtomId: null,
      undoStack: [...state.undoStack, snapshot(state)],
      redoStack: [],
    });
  },

  undo: () => {
    const state = get();
    if (state.undoStack.length === 0) return;
    const prevStack = [...state.undoStack];
    const last = prevStack.pop() as HistorySnapshot;
    set({
      atoms: last.atoms,
      bonds: last.bonds,
      undoStack: prevStack,
      redoStack: [...state.redoStack, snapshot(state)],
      selectedAtomId: null,
      pendingBondAtomId: null,
    });
  },

  redo: () => {
    const state = get();
    if (state.redoStack.length === 0) return;
    const nextStack = [...state.redoStack];
    const next = nextStack.pop() as HistorySnapshot;
    set({
      atoms: next.atoms,
      bonds: next.bonds,
      redoStack: nextStack,
      undoStack: [...state.undoStack, snapshot(state)],
      selectedAtomId: null,
      pendingBondAtomId: null,
    });
  },
}));
