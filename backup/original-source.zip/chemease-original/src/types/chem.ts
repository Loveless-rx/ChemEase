// src/types/chem.ts
//
// Shared, engine-agnostic types for the ChemEase editor UI.
// These describe the SHAPE of data the frontend renders — they intentionally
// hold no chemistry logic. When the real molecule model / drawing engine is
// wired in, these can be swapped for (or merged with) the engine's own types.

export type WorkspaceTool = "select" | "erase" | "lasso" | "draw" | "bond";

export type BondType = "single" | "double" | "triple" | "aromatic";

export type ElementSymbol = string;

export interface Atom {
  id: number;
  element: ElementSymbol;
  x: number;
  y: number;
  charge?: number;
}

export interface Bond {
  id: number;
  atomA: number;
  atomB: number;
  type: BondType;
}

export interface RingTemplate {
  id: "5-ring" | "6-ring" | "benzene";
  label: string;
  size: 5 | 6;
  aromatic: boolean;
}

export const COMMON_ELEMENTS: ElementSymbol[] = ["C", "H", "N", "O", "P", "S"];

export const HALOGEN_ELEMENTS: ElementSymbol[] = ["F", "Cl", "Br", "I"];

export const EXTENDED_ELEMENTS: ElementSymbol[] = [
  "Li", "Na", "K", "Mg", "Ca", "B", "Si", "Al", "Zn", "Fe", "Cu", "Ag",
];
